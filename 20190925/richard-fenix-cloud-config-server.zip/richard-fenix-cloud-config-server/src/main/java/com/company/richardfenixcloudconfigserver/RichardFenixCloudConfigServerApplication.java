package com.company.richardfenixcloudconfigserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RichardFenixCloudConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RichardFenixCloudConfigServerApplication.class, args);
	}

}
