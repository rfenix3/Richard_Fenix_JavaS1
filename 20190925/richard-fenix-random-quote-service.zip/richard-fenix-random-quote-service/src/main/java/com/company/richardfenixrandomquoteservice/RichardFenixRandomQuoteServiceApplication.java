package com.company.richardfenixrandomquoteservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RichardFenixRandomQuoteServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RichardFenixRandomQuoteServiceApplication.class, args);
	}

}
